# 3 small code changes required

## 1. src/services/apis.js (line 1)
-const BASE_URL = "https://study-notion-sbp0.onrender.com/api/v1"
+const BASE_URL = "/api/v1"

## 2. server/index.js (CORS block)
-		origin:"http://localhost:3000",
+		origin: process.env.CLIENT_URL || "http://localhost:3000",

## 3. server/controllers/ResetPassword.js (line 28)
-		const url = `http://localhost:3000/update-password/${token}`;
+		const url = `${process.env.CLIENT_URL || "http://localhost:3000"}/update-password/${token}`;
